# v1225 数据导入到 Neo4j

## 功能说明

这个脚本用于将 v1225 的教育知识图谱数据导入到 Neo4j 数据库。

## 数据结构

### 实体（entities/）

| 文件名 | 实体类型 | 说明 |
|--------|---------|------|
| Theme.json | Theme | 主题（如：数与运算、数量关系）|
| Chapter_primary.json | Chapter | 小学章节（1-6年级）|
| Chapter_middle.json | Chapter | 中学章节（7-9年级）|
| CoreLiteracyAspect.json | CoreLiteracyAspect | 核心素养方面 |
| CoreLiteracyPerformance.json | CoreLiteracyPerformance | 核心素养表现 |
| CourseGoal.json | CourseGoal | 课程目标 |
| kp.json | Kp | 知识点 |
| LearningDomain.json | LearningDomain | 学习领域 |
| LearningDomain_v2.json | LearningDomain | 学习领域（v2版本）|
| Prolems.json | Problem | 问题 |
| Stage.json | Stage | 学段（第一、二、三、四学段）|
| Stage_with_theme.json | Stage | 学段（带主题）|
| Section_middle.json | Section | 节 |

### 关系（relations/）

| 文件名 | 关系类型 | 说明 |
|--------|---------|------|
| Theme_Chapter_primary.json | HAS_CHAPTER | 主题包含章节（小学）|
| Theme_Chapter_middle.json | HAS_CHAPTER | 主题包含章节（中学）|
| Theme_CoreLiteracyAspect.json | INVOLVES_ASPECT | 主题涉及素养方面 |
| Theme_CoreLiteracyPerformance.json | INVOLVES_PERFORMANCE | 主题涉及素养表现 |
| theme_kp.json | HAS_KP | 主题包含知识点 |
| CoreLiteracyAspect_CoreLiteracyPerformance.json | HAS_PERFORMANCE | 素养方面包含表现 |
| Stage_LearningDomain.json | HAS_DOMAIN | 学段包含领域 |
| LearningDomain_Theme.json | CONTAINS_THEME | 领域包含主题 |
| CourseGoal_Stage.json | HAS_STAGE | 课程目标包含学段 |
| Problem_CoreLiteracyPerformance.json | DEMONSTRATES_PERFORMANCE | 问题体现素养表现 |
| problem_theme.json | RELATES_TO_THEME | 问题关联主题 |
| Promblem_kp.json | INVOLVES_KP | 问题涉及知识点 |
| Kp_CoreLiteracyPerformance.json | DEMONSTRATES_PERFORMANCE | 知识点体现素养表现 |

## 导入策略

### 1. 批量导入
- 使用 UNWIND 语句进行批量导入，提高性能
- 批量大小：每批 100 个实体/关系
- 使用 MERGE 语句避免重复数据

### 2. 约束和索引
- 为所有实体的 identifier 创建唯一约束
- 提高查询性能和导入速度
- 防止重复数据

### 3. 导入顺序
1. 先导入所有实体（创建节点）
2. 再导入关系（创建边）
3. 最后验证导入结果

### 4. 错误处理
- 批量导入失败时自动降级为逐个导入
- 详细记录失败原因
- 继续处理后续数据

## 安装依赖

```bash
pip install neo4j
```

## 使用方法

### 1. 启动 Neo4j 数据库

确保 Neo4j 数据库正在运行：

```bash
# 使用 Docker
docker run -d \
    --name neo4j \
    -p 7474:7474 -p 7687:7687 \
    -e NEO4J_AUTH=neo4j/lintianyu \
    -e NEO4J_PLUGINS=["apoc"] \
    neo4j:latest
```

### 2. 配置连接信息

编辑 `main.py` 中的连接配置：

```python
NEO4J_LOCAL_URI = "bolt://localhost:7687"
NEO4J_LOCAL_USER = "neo4j"
NEO4J_LOCAL_PASSWORD = "lintianyu"
NEO4J_LOCAL_DATABASE = "edukg-1225"
```

### 3. 运行导入脚本

```bash
cd v1225_副本
python main.py
```

### 4. 交互式选项

运行后会询问是否清空数据库：
- 输入 `yes` 或 `y`：清空现有数据并重新导入
- 其他任何键：保留现有数据，追加导入

## 导入流程

1. **检查连接**：验证 Neo4j 连接是否正常
2. **清空数据库**（可选）：删除所有现有数据
3. **创建约束**：为实体创建唯一约束
4. **导入实体**：导入所有实体节点
5. **导入关系**：导入所有关系边
6. **验证结果**：检查导入统计和孤立节点

## 验证查询

导入完成后，可以使用以下查询验证数据：

### 查看所有节点类型

```cypher
MATCH (n)
RETURN labels(n)[0] AS type, count(n) AS count
ORDER BY count DESC
```

### 查看所有关系类型

```cypher
MATCH ()-[r]->()
RETURN type(r) AS type, count(r) AS count
ORDER BY count DESC
```

### 查看主题及其章节

```cypher
MATCH (t:Theme)-[r:HAS_CHAPTER]->(c:Chapter)
RETURN t.title AS theme, c.title AS chapter, c.applicableLevel AS level
ORDER BY level, theme, chapter
LIMIT 50
```

### 查看孤立节点

```cypher
MATCH (n)
WHERE NOT (n)-[]-()
RETURN labels(n)[0] AS type, n.identifier, n.title
LIMIT 20
```

### 查看核心素养关系

```cypher
MATCH (t:Theme)-[r:INVOLVES_ASPECT]->(a:CoreLiteracyAspect)
RETURN t.title AS theme, a.title AS aspect
LIMIT 20
```

## 性能优化建议

1. **增加 Neo4j 内存**：调整 `neo4j.conf` 中的 `dbms.memory.heap.initial_size` 和 `dbms.memory.heap.max_size`
2. **调整批量大小**：根据服务器性能调整 `batch_size`
3. **使用索引**：为常用查询字段创建索引
4. **并行导入**：可以拆分文件并行导入（注意先导入实体再导入关系）

## 常见问题

### Q: 导入速度慢怎么办？
A: 可以尝试：
- 增加 Neo4j 内存配置
- 调大批量大小（修改 `batch_size = 100`）
- 确保网络连接正常

### Q: 出现连接错误怎么办？
A: 检查：
- Neo4j 是否正在运行
- 连接配置是否正确
- 防火墙是否允许连接

### Q: 如何部分导入？
A: 可以修改 `main.py` 中的 `entity_files` 和 `relation_files` 字典，注释掉不需要导入的文件。

### Q: 导入后如何查询？
A: 使用 Neo4j Browser（http://localhost:7474）或 Cypher Shell 进行查询。

## 数据统计

预期导入结果：

| 类型 | 数量 |
|------|------|
| Theme | ~24 |
| Chapter | ~113 |
| CoreLiteracyAspect | ~10 |
| CoreLiteracyPerformance | ~30 |
| CourseGoal | ~4 |
| Kp | ~100 |
| LearningDomain | ~15 |
| Problem | ~50 |
| Stage | ~4 |
| Section | ~500 |
| **总计（实体）** | **~850** |

| 关系类型 | 数量 |
|---------|------|
| HAS_CHAPTER | ~113 |
| INVOLVES_ASPECT | ~50 |
| INVOLVES_PERFORMANCE | ~100 |
| HAS_KP | ~100 |
| HAS_PERFORMANCE | ~30 |
| HAS_DOMAIN | ~12 |
| CONTAINS_THEME | ~24 |
| HAS_STAGE | ~4 |
| DEMONSTRATES_PERFORMANCE | ~50 |
| RELATES_TO_THEME | ~50 |
| INVOLVES_KP | ~100 |
| **总计（关系）** | **~633** |

## 注意事项

1. **备份数据**：导入前建议备份现有数据库
2. **测试环境**：建议先在测试环境验证
3. **分批导入**：大量数据可以分批导入
4. **监控日志**：关注导入过程中的错误和警告
5. **验证完整性**：导入后务必验证数据完整性

## 技术支持

如遇到问题，请检查：
1. Neo4j 日志
2. 脚本输出
3. 数据文件格式

## 更新日志

- v1.0.0 (2025-12-25): 初始版本，支持 v1225 数据导入

